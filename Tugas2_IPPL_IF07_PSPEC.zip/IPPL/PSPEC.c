#include <stdio.h>
#include <string.h>
#include <stdbool.h>

// Struktur untuk menyimpan data user
typedef struct {
    char username[50];
    char password[50]; // Simulasi password, tidak terenkripsi di sini
    char email[50];
} User;

// Struktur untuk menyimpan data transaksi
typedef struct {
    char username[50];
    int jumlahPembayaran;
    char tanggal[20]; // Simulasi tanggal
} Transaksi;

// Database user dan transaksi
User database[100]; // Maksimal 100 user
Transaksi transaksi[100]; // Maksimal 100 transaksi
int userCount = 0;
int transaksiCount = 0;

// Fungsi registrasi user
bool registrasiUser(char username[], char password[], char email[]) {
    // Cek apakah username sudah ada
    for (int i = 0; i < userCount; i++) {
        if (strcmp(database[i].username, username) == 0) {
            printf("Username sudah terdaftar.\n");
            return false;
        }
    }

    // Menambahkan user ke database
    strcpy(database[userCount].username, username);
    strcpy(database[userCount].password, password);
    strcpy(database[userCount].email, email);
    userCount++;

    printf("Registrasi berhasil dengan user : %s\n", username);
    return true;
}

// Fungsi login user
bool loginUser(char username[], char password[]) {
    // Cek apakah user ada di database
    for (int i = 0; i < userCount; i++) {
        if (strcmp(database[i].username, username) == 0) {
            // Verifikasi password
            if (strcmp(database[i].password, password) == 0) {
                printf("Login berhasil dengan user : %s\n", username);
                return true;
            } else {
                printf("Password salah.\n");
                return false;
            }
        }
    }

    printf("User tidak ditemukan.\n");
    return false;
}

// Fungsi proses pembayaran
bool prosesPembayaran(char username[], int jumlahPembayaran, char tanggal[]) {
    // Cek apakah user ada di database
    bool userFound = false;
    for (int i = 0; i < userCount; i++) {
        if (strcmp(database[i].username, username) == 0) {
            userFound = true;
            break;
        }
    }

    if (!userFound) {
        printf("User tidak ditemukan.\n");
        return false;
    }

    // Simpan transaksi
    strcpy(transaksi[transaksiCount].username, username);
    transaksi[transaksiCount].jumlahPembayaran = jumlahPembayaran;
    strcpy(transaksi[transaksiCount].tanggal, tanggal);
    transaksiCount++;

    printf("Pembayaran sebesar Rp. %d berhasil dengan user: %s\n", jumlahPembayaran, username);
    return true;
}

// Fungsi menampilkan laporan transaksi
void laporanTransaksi(char username[]) {
    bool transaksiDitemukan = false;
    printf("Laporan transaksi dengan user : %s\n", username);

    // Mencari transaksi user
    for (int i = 0; i < transaksiCount; i++) {
        if (strcmp(transaksi[i].username, username) == 0) {
            printf("Transaksi %d dengan Jumlah : Rp. %d, Tanggal : %s\n", i + 1, transaksi[i].jumlahPembayaran, transaksi[i].tanggal);
            transaksiDitemukan = true;
        }
    }

    if (!transaksiDitemukan) {
        printf("Tidak ada transaksi dengan user : %s\n", username);
    }
}

int main() {
    // Registrasi user
    registrasiUser("user1", "password123", "user1@example.com");
    // Login user
    loginUser("user1", "password123");
    // Proses pembayaran
    prosesPembayaran("user1", 50000, "17-12-2024");
    // Laporan transaksi
    laporanTransaksi("user1");

    return 0;
}
